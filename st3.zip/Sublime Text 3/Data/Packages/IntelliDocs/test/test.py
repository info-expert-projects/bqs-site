Dont run this file, just for testing purposes! :)
-------------------------------------------------

self.patterns[pattern_name].format(name = entry["name"])
re.match(self.patterns["skip"], entry["name"])
match.group(1)
part.strip()
open(path_db+"/"+self.name+".json", "w").write(json.dumps(db, sort_keys=True, indent=4))
s.replace("\n", "")
bytes.fromhex('2Ef0 F1f2  ')
for directory, name in docs.items():