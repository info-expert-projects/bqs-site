Dont run this file, just for testing purposes! :)
-------------------------------------------------

return val.toLowerCase();
clearTimeout($.gsuggest.suggestDelay);
setTimeout($.gsuggest.suggestDelay);
if ($.gsuggest.config.debug)timerstart = new Date().getTime();
data.sort();
new RegExp("("+escapeRe(objval).replace(/ /g, "|")+")","gi")
$(id).click(function(){$(this).blur(); $(this).focus()});
console.log("inited");
document.getElementById("map_canvas")
var c_lat = parseFloat( min_lat) + parseFloat((max_lat-min_lat)/2);
el = document.createElement("div");
me.latlngs.push({latlng: latlng, c: d[dlen].count}); 

$("#pp"+last_pppid).removeClass("selected");
$(row).appendTo($('#valaszto'));
$('#selected_pickpack_title').html('&nbsp;');
return $(e.target).parents().children().filter('div.blockUI').length == 0;
$( document ).ajaxComplete(function() { $( ".log" ).text( "Triggered ajaxComplete handler." ); });
console.log( $( this ).serializeArray() );
$.each( fields, function( i, field ) { $( "#results" ).append( field.value + " " ); }).each();

elem.addClass "flash"
elem[0].remove