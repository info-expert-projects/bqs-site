<?
Dont run this file, just for testing purposes! :)
-------------------------------------------------

$urls = explode("/", $url);
urlencode($query);
$name = str_replace("/", " ", $name);
return preg_replace("#[^A-Za-z0-9\. $extra-]#", "", $name);
rtrim($hash, "/");
return (substr($s, 0-$end_len) == $end);
if (strpos($s, $part) === false) return false;
return htmlspecialchars($value, ENT_QUOTES);
return base_convert($rand, 10, 36);
?>
<script>
$("#elem").removeClass("flash")
setTimeout (-> 
	alert "test Coffeescript!"
), 1000
</script>